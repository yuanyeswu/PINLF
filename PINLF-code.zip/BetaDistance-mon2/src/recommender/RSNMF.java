package recommender;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import recommender.common.CommonRecomm_NoBias;
import recommender.common.RTuple;

//浣跨敤Tikhonov姝ｅ垯鍖栵紝涓嶅甫鏈夌嚎鎬у亸宸殑NMF
public class RSNMF extends CommonRecomm_NoBias 
{

	public RSNMF() throws NumberFormatException, IOException 
	{
		super();
		this.ifBi = false;
		this.ifBu = false;
		this.ifMu = false;
	}
	
	public void train() throws IOException 
	{
		FileWriter fwRMSE = new FileWriter("D:\\6.13"+System.currentTimeMillis()+".txt");	
		fwRMSE.write("********************************************************\n");
		fwRMSE.flush();
		fwRMSE.write(lambda+"\t"+Kp+"\t"+Ki+"\t"+Kd+"\n");
		fwRMSE.flush();
		for (int round = 1; round <= trainingRound; round++) 
		{
			// 灏嗙浉鍏崇殑杈呭姪鍙橀噺缃负0
			resetNMFAuxArrays();
		    double time1 = System.currentTimeMillis();
			for (RTuple tempRating : trainData) 
			{
				// 姝ゅ寮�濮嬪涔�
				double ratingHat = this.getLocPrediction(tempRating.iUserID,
						tempRating.iItemID, this.ifMu, this.ifBi, this.ifBu);
                
				// 璁板綍Bias涓婄殑瀛︿範澧為噺
				userBiasUp[tempRating.iUserID] += tempRating.dRating;
				userBiasDown[tempRating.iUserID] += ratingHat;	
				itemBiasUp[tempRating.iItemID] += tempRating.dRating;
				itemBiasDown[tempRating.iItemID] += ratingHat;	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////												
				
					
					for (int dimen = 0; dimen < featureDimension; dimen++)
					{
						userFactorUp[tempRating.iUserID][dimen] += itemFeatureArray[tempRating.iItemID][dimen]
								* tempRating.dRating;
						userFactorDown[tempRating.iUserID][dimen] += itemFeatureArray[tempRating.iItemID][dimen]
								* ratingHat + userFeatureArray[tempRating.iUserID][dimen] * lambda;
					
						itemFactorUp[tempRating.iItemID][dimen] += userFeatureArray[tempRating.iUserID][dimen]
								* tempRating.dRating;
						itemFactorDown[tempRating.iItemID][dimen] += userFeatureArray[tempRating.iUserID][dimen]
								* ratingHat + itemFeatureArray[tempRating.iItemID][dimen] * lambda;
					}
			    	

			}
			// 灏嗘墍鏈夌殑澧為噺锛屾牴鎹敤鎴峰拰椤圭洰鐨処D锛屽姞鍒扮浉搴旂殑闅愬悜閲忎笂
			for (int tempUserID = 1; tempUserID <= maxUserID; tempUserID++)
			{
				userBiasDown[tempUserID] += userBias[tempUserID] * userRSetSize[tempUserID] * lambda;
				if(userBiasDown[tempUserID] != 0)
					userBias[tempUserID] *= (userBiasUp[tempUserID]/userBiasDown[tempUserID]);				
				for (int dimen = 0; dimen < featureDimension; dimen++) 
				{
					userFeatureArrayLatest[tempUserID][dimen] = userFeatureArray[tempUserID][dimen];
					if (userFactorDown[tempUserID][dimen] != 0)
						userFeatureArray[tempUserID][dimen] *= (userFactorUp[tempUserID][dimen] / userFactorDown[tempUserID][dimen]);  ///SLF-NMU计算的隐特征
				}
			}

			for (int tempItemID = 1; tempItemID <= maxItemID; tempItemID++) 
			{
				itemBiasDown[tempItemID] += itemBias[tempItemID] * itemRSetSize[tempItemID] * lambda;
				if(itemBiasDown[tempItemID] != 0)
					itemBias[tempItemID] *= (itemBiasUp[tempItemID]/itemBiasDown[tempItemID]);			
				
				for (int dimen = 0; dimen < featureDimension; dimen++)
				{
					itemFeatureArrayLatest[tempItemID][dimen] = itemFeatureArray[tempItemID][dimen];
					if (itemFactorDown[tempItemID][dimen] != 0) 
					{
						itemFeatureArray[tempItemID][dimen] *= (itemFactorUp[tempItemID][dimen] / itemFactorDown[tempItemID][dimen]);  ///SLF-NMU计算的隐特征
					}
				}
			}
			
			for (int tempUserID = 1; tempUserID <= maxUserID; tempUserID++)
			{			
				for (int dimen = 0; dimen < featureDimension; dimen++) 
				{
				  userFeatureArrayPredelta[tempUserID][dimen] = userFeatureArrayLatestdelta[tempUserID][dimen];
				  userFeatureArrayLatestdelta[tempUserID][dimen] = userFeatureArray[tempUserID][dimen] - userFeatureArrayLatest[tempUserID][dimen];
				  userFeatureArraydeltaSum[tempUserID][dimen] += userFeatureArrayLatestdelta[tempUserID][dimen]; 
				  userFeatureArraydeltaSub[tempUserID][dimen] = userFeatureArrayLatestdelta[tempUserID][dimen] - userFeatureArrayPredelta[tempUserID][dimen];
				  userFeatureArrayPID[tempUserID][dimen] = 1 * userFeatureArrayLatestdelta[tempUserID][dimen] + 0.04 * userFeatureArraydeltaSum[tempUserID][dimen]
						                                   - 0.00 * userFeatureArraydeltaSub[tempUserID][dimen];
				  userFeatureArray[tempUserID][dimen] = userFeatureArrayLatest[tempUserID][dimen] +  userFeatureArrayPID[tempUserID][dimen];
				  if (userFeatureArray[tempUserID][dimen] <0)
					  userFeatureArray[tempUserID][dimen] = 0;
				}
			}

			for (int tempItemID = 1; tempItemID <= maxItemID; tempItemID++) 
			{		
				for (int dimen = 0; dimen < featureDimension; dimen++)
				{
				  itemFeatureArrayPredelta[tempItemID][dimen] = itemFeatureArrayLatestdelta[tempItemID][dimen];
				  itemFeatureArrayLatestdelta[tempItemID][dimen] = itemFeatureArray[tempItemID][dimen] - itemFeatureArrayLatest[tempItemID][dimen];
				  itemFeatureArraydeltaSum[tempItemID][dimen] += itemFeatureArrayLatestdelta[tempItemID][dimen];
				  itemFeatureArraydeltaSub[tempItemID][dimen] = itemFeatureArrayLatestdelta[tempItemID][dimen]-itemFeatureArrayPredelta[tempItemID][dimen];		
				  itemFeatureArrayPID[tempItemID][dimen] = 1 * itemFeatureArrayLatestdelta[tempItemID][dimen] + 0.04 * itemFeatureArraydeltaSum[tempItemID][dimen]
                                                           - 0.00 * itemFeatureArraydeltaSub[tempItemID][dimen];
				  itemFeatureArray[tempItemID][dimen] = itemFeatureArrayLatest[tempItemID][dimen] + itemFeatureArrayPID[tempItemID][dimen];
				  if (itemFeatureArray[tempItemID][dimen] < 0)
					  itemFeatureArray[tempItemID][dimen] = 0;
					  
				}
			}
				
			
	///////////////////////////////////////判断是否为第1轮///////////////////////////////////////////////////////////////					
//		if(round == 1)
//		{
//			for (int tempUserID = 1; tempUserID <= maxUserID; tempUserID++)
//			{			
//				for (int dimen = 0; dimen < featureDimension; dimen++) 
//				{
//					    userFeatureArrayLatest[tempUserID][dimen] = userFeatureArray[tempUserID][dimen];
//				}
//			}
//
//			for (int tempItemID = 1; tempItemID <= maxItemID; tempItemID++) 
//			{	
//				for (int dimen = 0; dimen < featureDimension; dimen++)
//				{					
//						itemFeatureArrayLatest[tempItemID][dimen] = itemFeatureArray[tempItemID][dimen];
//				}
//			}									
//		}
//	
//		else
//		{
//			for (int tempUserID = 1; tempUserID <= maxUserID; tempUserID++)
//			{			
//				for (int dimen = 0; dimen < featureDimension; dimen++) 
//				{									
//					double Ummt = userFeatureArrayLatest[tempUserID][dimen] -  userFeatureArrayLatestPre[tempUserID][dimen];    ///动量
//				    Ummt = (Ummt  > 0) ? Ummt : 0;                                                                                ///判断动量和0的大小
//				    userFeatureArray[tempUserID][dimen] += ganma * Ummt;                                                       ///加入动量
//				    userFeatureArrayLatestPre[tempUserID][dimen] = userFeatureArrayLatest[tempUserID][dimen];                 ////存储t-2时刻的隐特征
//					userFeatureArrayLatest[tempUserID][dimen] = userFeatureArray[tempUserID][dimen];                 ////存储t-1时刻的隐特征
//				}						
//			}
//			for (int tempItemID = 1; tempItemID <= maxItemID; tempItemID++) 
//			{	
//				for (int dimen = 0; dimen < featureDimension; dimen++)
//				{
//					double Immt = itemFeatureArrayLatest[tempItemID][dimen] -  itemFeatureArrayLatestPre[tempItemID][dimen];    ///动量
//					Immt = (Immt  > 0) ? Immt : 0;                                                                                ///判断动量和0的大小
//					itemFeatureArray[tempItemID][dimen] += ganma * Immt;                                                       ///加入动量
//					itemFeatureArrayLatestPre[tempItemID][dimen] = itemFeatureArrayLatest[tempItemID][dimen];                  ///存储t-2时刻的隐特征
//					itemFeatureArrayLatest[tempItemID][dimen] = itemFeatureArray[tempItemID][dimen];                          ////存储t-1时刻的隐特征
//				}
//			}
//						
//		}
		double time2 = System.currentTimeMillis();
		double time3 = (time2-time1)/1000;
//////////////////////////////////////////////////////////////////////////////////
			// 璁＄畻鏈疆璁粌缁撴潫鍚庯紝鍦ㄦ祴璇曢泦涓婄殑RMSE////
		   // fwRMSE.flush();	
			double sumRMSE = 0, sumCount = 0, sumMAE = 0;
			for (RTuple tempvalRating : validationData)
			{
				double actualRating = tempvalRating.dRating;
				double ratinghat = this.getLocPrediction(tempvalRating.iUserID, tempvalRating.iItemID);

							sumRMSE += Math.pow((actualRating - ratinghat),2);
//			   			    sumMAE += Math.abs(actualRating - ratinghat);
				sumCount++;
			}
			 	   double RMSE = Math.sqrt(sumRMSE / sumCount);
// 		    	   double RMSE = sumMAE / sumCount;
			///////////////////////////////////////////////////////			
				   
			lastRMSE = this.minRMSE;			
			if (this.minRMSE > RMSE) 
			{
				this.minRMSE = RMSE;                 
				this.minRound = round;   
				cacheMinFeatures();
			} 					
			System.out.println(this.countRMSE+"\t"+this.minRMSE+"\t"+this.lastRMSE+"\t"+round+"\t"+RMSE+"\t"+time3);	
			fwRMSE.write(round+"\t"+RMSE+"\n");
		    System.gc();   
		    fwRMSE.flush();
			if(this.minRMSE == this.lastRMSE)
			{
				 countRMSE = 0;
			}
			else countRMSE += 1;				
		    if((Math.abs(this.minRMSE - this.lastRMSE)<minGap) && (countRMSE>2))
			{
				break;
			}	
			if(Math.abs(this.minRound - round)>=delayCount)
			{
				break;
			}
		}				
		double sumRMSE = 0, sumCount = 0, sumMAE = 0;
		for (RTuple tempTestRating : testData)
		{
			double actualRating = tempTestRating.dRating;
			double ratinghat = this.getMinPrediction(
					tempTestRating.iUserID, tempTestRating.iItemID);

				sumRMSE += Math.pow((actualRating - ratinghat),2);
//				sumMAE += Math.abs(actualRating - ratinghat);
			sumCount++;
		}
			double RMSEinput = Math.sqrt(sumRMSE / sumCount);
//			double RMSEinput = sumMAE / sumCount;
		errorinput = RMSEinput;
		System.out.println(minRound+"\t"+errorinput);
		fwRMSE.write(minRound+"\t"+errorinput+"\n"+maxUserID+"\n"+maxItemID+"\n"+countNum+"\n"); 					
		fwRMSE.close();
	}
	
	
	public static void main(String[] argv) throws NumberFormatException,
			IOException
	{					
		//for(double i= 0; i <0.11; i =i + 0.01)
		{		
		  //for(double j = 0.01; j <0.11; j = j +0.01)	
		  {	      
			    minRMSE = 100;				
				minRound = 0;	
			   CommonRecomm_NoBias.initializeRatings("D:\\dataset\\ML10M\\train.txt","D:\\dataset\\ML10M\\validation.txt","D:\\dataset\\ML10M\\test.txt","::");
			   CommonRecomm_NoBias. countRMSE = 0;
				CommonRecomm_NoBias.lambda = 0.08;
				CommonRecomm_NoBias.Kp = 1;
				CommonRecomm_NoBias.Ki = 0.00;
				CommonRecomm_NoBias.Kd = -0.0000;
				CommonRecomm_NoBias.trainingRound = 1000;
				CommonRecomm_NoBias.featureDimension = 5;
				CommonRecomm_NoBias.delayCount = 10;				
				CommonRecomm_NoBias.minMAE = 100;
				CommonRecomm_NoBias.minRMSE = 100;				
				CommonRecomm_NoBias.lastRMSE = 100;				
				CommonRecomm_NoBias.minRound = 0;
				CommonRecomm_NoBias.minGap =0.00001;
				CommonRecomm_NoBias.Num();
				CommonRecomm_NoBias.initiStaticFeatures();
			 RSNMF testBRISMF = new RSNMF();
		     testBRISMF.train();	
		  }
		}
	}
}





