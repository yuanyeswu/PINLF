package recommender.common;

public class RTuple {
	
	public int iUserID = 0;
	
	public int iItemID = 0;
	
	public double dRating = 0;
	
	public double dRatingHat = 0;
	
	public double lTimeStamp = 0;				
}
